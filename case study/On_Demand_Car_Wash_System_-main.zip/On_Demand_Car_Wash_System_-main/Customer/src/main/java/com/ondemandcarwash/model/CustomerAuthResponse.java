package com.ondemandcarwash.model;

public class CustomerAuthResponse {
	
	private String Response;
	
	public CustomerAuthResponse() {
		
	}

	public CustomerAuthResponse(String response) {
		super();
		Response = response;
	}

	public String getResponse() {
		return Response;
	}

	public void setResponse(String response) {
		Response = response;
	}

	

}
