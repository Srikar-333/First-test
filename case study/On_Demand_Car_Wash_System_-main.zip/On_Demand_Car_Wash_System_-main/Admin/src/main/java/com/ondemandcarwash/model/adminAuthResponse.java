package com.ondemandcarwash.model;

public class adminAuthResponse {

	private String Response;
	
	public adminAuthResponse() {
		
	}

	public adminAuthResponse(String response) {
		super();
		Response = response;
	}

	public String getResponse() {
		return Response;
	}

	public void setResponse(String response) {
		Response = response;
	}

	
}
