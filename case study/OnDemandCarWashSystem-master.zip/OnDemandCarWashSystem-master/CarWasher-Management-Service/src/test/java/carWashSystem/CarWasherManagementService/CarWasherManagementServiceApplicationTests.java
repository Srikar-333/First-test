package carWashSystem.CarWasherManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarWasherManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
