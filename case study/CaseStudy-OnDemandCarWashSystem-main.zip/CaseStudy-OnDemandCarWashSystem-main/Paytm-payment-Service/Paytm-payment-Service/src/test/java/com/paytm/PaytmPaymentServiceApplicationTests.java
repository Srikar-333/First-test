package com.paytm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaytmPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
