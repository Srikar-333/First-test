import React, { Component } from 'react';

class Payment extends Component {
    render() {
        return (
            <div>
                <h1>hzgh</h1>
               
                <h1>hzgh</h1>
            </div>
        );
    }
}

export default Payment;